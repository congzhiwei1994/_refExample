import os
import rna_keymap_ui
from . import operators
import traceback
from . import developer_utils
import importlib
import bpy
from bpy.types import (
	Panel,
	Operator,
	AddonPreferences,
	PropertyGroup,
)
'''
Copyright (C) 2018 PJ PENG
pjwaixingren@me.com

Created by pjpeng

	This program is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

bl_info = {
	"name": "BGManager",
	"description": "This addon use to development Game",
	"author": "pjwaixingren",
	"version": (0, 1, 0),
	"blender": (2, 80, 0),
	"location": "View3D",
	"warning": "This addon is still in development.",
	"wiki_url": "www.pjcgart.com",
	"category": "Object"}


# load and reload submodules
##################################

importlib.reload(developer_utils)
modules = developer_utils.setup_addon_modules(
	__path__, __name__, "bpy" in locals())


# register
##################################

class bgamemanager_preferences(bpy.types.AddonPreferences):
	bl_idname = __name__

	def draw(self, context):
		layout = self.layout
		
		row = layout.row()
		col = row.column()
		
		col.separator()
		# col.separator()
		#view3d colors
		# row = col.row(align=True)
		####################################################################
		# col.label(text="SUV Keymap List",icon="KEYINGSET")
		wm = bpy.context.window_manager
		kc = wm.keyconfigs.user
		old_km_name = ""
		get_kmi_l = []
		for km_add, kmi_add in bgm_addon_keymaps:
			for km_con in kc.keymaps:
				if km_add.name == km_con.name:
					km = km_con
					break

			for kmi_con in km.keymap_items:
				if kmi_add.idname == kmi_con.idname:
					if kmi_add.name == kmi_con.name:
						get_kmi_l.append((km,kmi_con))

		get_kmi_l = sorted(set(get_kmi_l), key=get_kmi_l.index)

		for km, kmi in get_kmi_l:
			if not km.name == old_km_name:
				col.label(text=str(km.name),icon="DOT")
			col.context_pointer_set("keymap", km)
			rna_keymap_ui.draw_kmi([], kc, km, kmi, col, 0)
			col.separator()
			old_km_name = km.name
		####################################################################
		col.separator()


class bgamemanager_fbx(bpy.types.Panel):
	bl_idname = "bgamemanagernamefbxnew"
	bl_label = "Im&Ex Select MESHS"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "BGManager"
	# -----

	def draw(self, context):
		layout = self.layout
		scene = context.scene

		row = layout.row(align=True)

		row.scale_x = 0.1
		row.scale_y = 1.0
		row.label(text="ParName:")
		rowpn = row.row(align=True)
		# row2.alignment='RIGHT'
		rowpn.scale_x = 0.40
		rowpn.scale_y = 1.0
		rowpn.prop(scene, "fbxcommonname")
		rowx = layout.row(align=True)
		rowx.label(text="Set Center:")
		# rowx.scale_x = 0.5
		# rowx.scale_y = 1.0
		rowpn = rowx.row(align=True)
		rowpn.scale_x = 1
		rowpn.scale_y = 1.0
		rowpn.prop(scene, "fbxsetcenter")
		layout.row(align=True)
		layout.prop(scene, "meshtype")
		if bpy.context.scene.meshtype =='fbx':
			layout.operator('my_operator.bgmimportfbx',
							text='Import FBX MESH', icon="IMPORT")
			layout.operator('my_operator.bgmexportfbxnew',
						text='Export FBX MESH', icon="EXPORT")
		else:
			layout.operator('my_operator.bgmimportobj',
							text='Import OBJ MESH', icon="IMPORT")
			layout.operator('my_operator.bgmexportfbxnew',
							text='Export OBJ MESH', icon="EXPORT")

class bgamemanager_setarray(bpy.types.Panel):
	bl_idname = "bgamemanagersetarray"
	bl_label = "Array Objects"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "BGManager"
	# ------GET SP PATH---------

	# -------------------------

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		layout.prop(scene, "objectsetarrary" ,expand=True)
		if bpy.context.scene.objectsetarrary == 'Collection1':
			layout.prop(scene, "objectsetarrary_getcollection")
		layout.prop(scene, "objectsetarrary_mode" ,expand=True)
		if bpy.context.scene.objectsetarrary_mode=="Array":
			layout.prop(scene, "objectsetarrary_dirction",expand=True)
			layout.prop(scene, "objectsetarrary_Number")
			row = layout.row(align=True)
			row.prop(scene, "objectsetarrary_Marginw")
			row.prop(scene, "objectsetarrary_Marginh")
			
		layout.prop(scene, "objectsetarrary_put_center",expand=True)
		layout.operator('my_operator.bgmsetarray',
						text='Array Objects', icon="MODIFIER_OFF")
		


class bgamemanager_setname(bpy.types.Panel):
	bl_idname = "bgamemanagersetname"
	bl_label = "Set Name"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "BGManager"
	# ------GET SP PATH---------

	# -------------------------

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		row = layout.row(align=True)
		layout.prop(scene, "renametype" ,expand=True)
		if bpy.context.scene.renametype=="rename":
			rowpn = layout.row(align=True)
			rowpn.label(text="SetName:")
			rowpn.prop(scene, "setname")
			rowxx =layout.row(align=True)
			rowxx.prop(scene, "startnumber")
			rowxx.prop(scene, "suffixzeros")
			
			rowpnn = layout.row(align=True)

			rowpnn.label(text="Invert Rename:")
			rowpnn.row(align=True)
			rowpnn.prop(scene, "invertrename")
			
			layout.operator('my_operator.bgamemanagersetname',
							text='Rename Object', icon="MODIFIER_OFF")

		if bpy.context.scene.renametype=="UseObjectName":
			layout.operator('my_operator.bgamemanageruseobjectname',
							text='UseObjectName', icon="MODIFIER_OFF")


class bgamemanager_SetTopo(bpy.types.Panel):
	bl_idname = "bgamemanagersettopo"
	bl_label = "Creat Topo"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "BGManager"

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		row = layout.row(align=True)
		layout.operator('my_operator.creatretopo',
						text='Creat Topo Layer', icon="MODIFIER_OFF")
	   


# class bgamemanager_SetNormal(bpy.types.Panel):
#     bl_idname = "bgamemanagersetnormal"
#     bl_label = "Setting Normals"
#     bl_space_type = "VIEW_3D"
#     bl_region_type = "UI"
#     bl_category = "BGManager"
#     # ------GET SP PATH---------

#     # -------------------------

#     def draw(self, context):
#         layout = self.layout
#         scene = context.scene
#         row = layout.row(align=True)
#         layout.operator("mesh.smoothen_normals")
#         layout.prop(scene, "setnormal")


# class bgamemanager_SetMat(bpy.types.Panel):
# 	bl_idname = "bgamemanagersetmat"
# 	bl_label = "Setting Materials"
# 	bl_space_type = "VIEW_3D"
# 	bl_region_type = "UI"
# 	bl_category = "BGManager"
# 	# ------GET SP PATH---------

# 	# -------------------------

# 	def draw(self, context):
# 		layout = self.layout
# 		scene = context.scene
# 		row = layout.row(align=True)

# 		row.scale_x = 0.1
# 		row.scale_y = 1.0
# 		row.label(text="SetMaterial:")
# 		rowpn = row.row(align=True)
# 		# row2.alignment='RIGHT'
# 		rowpn.scale_x = 0.40
# 		rowpn.scale_y = 1.0
# 		rowpn.prop(scene, "setmatrial")
# 		layout.operator('my_operator.bgmsettingmat',
# 						text='Setting Material', icon="MODIFIER_OFF")

class bgamemanager_bathmodifier(bpy.types.Panel):
	bl_idname = "bgamemanagerkeyanimation"
	bl_label = "Batch Set Modifier"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "BGManager"
	# ------GET SP PATH---------

	# -------------------------

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		#row = layout.row(align=True)
		layout.prop(scene, "batchsetmodifier" ,expand=True)
		if bpy.context.scene.batchsetmodifier == 'Collection1':
			layout.prop(scene, "batchsetmodifier_getcollection")       
		layout.prop(scene, "batchsetmodifier_getobj")
		row = layout.row(align=True)
		row.operator('my_operator.bgmsetaddmodiifer',
						text='Add Modifiers', icon="MODIFIER")
		row.operator('my_operator.bgmsetapplymodiifer',
						text='Apply Modifiers', icon="MODIFIER")
		row.operator('my_operator.bgmclearsetmodiifer',
						text='Clear Modifiers', icon="MODIFIER")


class bgamemanager_keyanimation(bpy.types.Panel):
	bl_idname = "bgamemanagerbathmodifier"
	bl_label = "Key Animation"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "BGManager"
	# ------GET SP PATH---------

	# -------------------------

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		
		# layout.operator('my_operator.bgmkeyanimation',
		#                 text='Key Animation', icon="ARMATURE_DATA")
		# row = layout.row(align=True)

		layout.operator('my_operator.bgmkeyanimation',
						text='Key Same Value', icon="ARMATURE_DATA")
		layout.operator('my_operator.bgmkeyclearanimationdata',
						text='Clear Useless Keys', icon="ARMATURE_DATA")



class bgamemanager_render(bpy.types.Panel):
	bl_idname = "bgamemanagerrender"
	bl_label = "Rander Animation"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "BGManager"
	# ------GET SP PATH---------

	# -------------------------

	def draw(self, context):

		layout = self.layout
		scene = context.scene
		row = layout.row(align=True)
		row.label(text="Re Collection:")
		rowa = row.row(align=True)
		rowa.prop(scene, "rendercollectionstr")
		rowxx = layout.row(align=True)
		rowxx.label(text="Render Angel:")
		rowpns = rowxx.row(align=True)
		rowpns.prop(scene, "renderangle")
		rowx = layout.row(align=True)
		rowx.label(text="Render Times:")
		rowpn = rowx.row(align=True)
		rowpn.prop(scene, "rendertimes")
		rowpnn = layout.row(align=True)
		rowpnn.label(text="Render Animation:")
		rowpnn.row(align=True)
		rowpnn.prop(scene, "rendertrue")  
		layout.operator('my_operator.bgamemanagerrender',
						text='Rander', icon="MODIFIER_OFF")


class bgamemanager_backanim(bpy.types.Panel):
	bl_idname = "bgamemanagernamebakeanimation"
	bl_label = "Bake Animation"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "BGManager"
	# ------GET SP PATH---------

	# -------------------------

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		# row = layout.row
		# row.scale_x = 0.1
		# row.scale_y = 1.0
		layout.prop(scene, "bakeanimation_obj" ,expand=True)
		if bpy.context.scene.bakeanimation_obj == 'Collection1':
			layout.prop(scene, "bakeanimation_getcollection")
		#layout.use_property_split = True
		layout.prop( scene, "bakeanimation_keytype",expand=True)
		layout.operator('my_operator.bakeanimation',
						text='Bake Animation', icon="MODIFIER_OFF")



class bgamemanager_paintersetting(bpy.types.Panel):
	bl_idname = "bgamemanagerpaintersetting"
	bl_label = "Painter Setting"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "BGManager"
	# ------GET SP PATH---------

	# -------------------------

	def draw(self, context):
		layout = self.layout
		scene = context.scene
		row = layout.row(align=True)
		row.scale_x = 0.1
		row.scale_y = 1.0
		layout.operator('my_operator.bgmpaintersetting',
						text='Painter Setting', icon="GREASEPENCIL")

		layout.prop(scene, "objectbake" ,expand=True)
		
		if bpy.context.scene.objectbake == 'Collection1':
			layout.prop(scene, "objectbake_getcollection")
		row = layout.row(align=True)   
		row.prop(scene, "objectbakesize" )
		row.prop(scene, "objectbakelightsize")
		layout.prop(scene, "objectbaketype" ,expand=True)
		if bpy.context.scene.objectbaketype=='DIFFUSE':
			layout.prop(scene, "objectdiffuselight" ,expand=True)

		layout.operator('my_operator.bgmpainterbaketype',
						text='Bake Texture', icon="GREASEPENCIL")


mainu = (
	bgamemanager_preferences,
	operators.bgm_exportfbx.bgmexportfbx,
	bgamemanager_fbx,
	operators.bgm_importfbx.ImportFbxData,
	operators.bgm_importfbx.ImportobjData,
	# bgamemanager_importfbx,
	operators.bgm_setarray.bgmsetarray,
	bgamemanager_setarray,
	operators.bgm_setname.bgmsetname,
	bgamemanager_setname, 
	operators.bgm_setname.bgmuseobjectname,
	#operators.bgm_setnormal.bgmsetnormal,
	#bgamemanager_SetTopo,
	#operators.bgm_creatretopo.bgmcreatretopo,
	# bgamemanager_SetNormal,
	operators.bgm_settingmat.bgmsettingmat,
	# bgamemanager_SetMat,
	# operators.bgm_paintersetting.bgmpaintersetting,
	#operators.bgm_paintersetting.bgmpainterbaketype,
	#bgamemanager_paintersetting,
	operators.bgm_setmodifier.bgmsetaddmodiifer,
	operators.bgm_setmodifier.bgmsetapplymodiifer,
	operators.bgm_setmodifier.bgmsetclearmodiifer,
	bgamemanager_bathmodifier,
	operators.bgm_bakeanimation.bgmexportbakeanimation,
	bgamemanager_backanim,
	operators.bgm_keyanimation.bgmkeyanimation,
	operators.bgm_keyanimation.bgmkeyclearanimationdata,
	# bgamemanager_keyanimation,
	#operators.bgm_renderfbx.bgmrender,
	#bgamemanager_render

)
classes = mainu
preview_collections = {}
bgm_addon_keymaps=[]
# ----------------------------------
def normal_update_func(self, context):
	bpy.ops.mesh.smoothen_normals(factor=bpy.context.scene.setnormal)
	print("")   

def add_keymap_to_ui(self, context, layout, k_name, idname):
	# keymap_item = context.window_manager.keyconfigs.addon.keymaps[k_name].keymap_items
	keymap_item = context.window_manager.keyconfigs.user.keymaps[k_name].keymap_items
	row = layout.row()
	km = context.window_manager.keyconfigs.user.keymaps[k_name]  # added
	layout.context_pointer_set("keymap", km)  # added
	row.prop(keymap_item[idname], 'active', text="",full_event=True)
	row.prop(keymap_item[idname], 'type', text=keymap_item[idname].name, full_event=True) 


def register():
	# bpy.types.Scene.spmeshseleted=bpy.props.BoolProperty(
	#     name='Sel_MESH',
	#     default=False,
	#     description='outmesh')
	# bpy.types.Scene.spmeshudmi=bpy.props.BoolProperty(name='Cre_UDIM',default=False)
	bpy.types.Scene.fbxcommonname = bpy.props.StringProperty(name="")
	bpy.types.Scene.fbxsetcenter = bpy.props.BoolProperty(name="", default=False)
	
	bpy.types.Scene.Keep_Vert_Order = bpy.props.BoolProperty(name="", default=False)
	bpy.types.Scene.Use_Object_name = bpy.props.BoolProperty(name="", default=False)

	bpy.types.Scene.meshtype=bpy.props.EnumProperty(
		name="MESH Type", 
		items=[('fbx','FBX','',0),('obj','OBJ','',1)],
		default='fbx',
	)

	bpy.types.Scene.objectsetarrary=bpy.props.EnumProperty(
		name="Set Array obj or collection", 
		items=[('obj1','Select_Object','',0),('Collection1','Select_Collection','',1)],
		default='obj1',
	)

	bpy.types.Scene.objectsetarrary_getcollection=bpy.props.PointerProperty(name="", type=bpy.types.Collection)
	bpy.types.Scene.objectsetarrary_mode=bpy.props.EnumProperty(
		name="Set Array Mode", 
		items=[('Center','Center','',0),('Array','Array','',1)],
		default='Center',
	)
	bpy.types.Scene.objectsetarrary_Number=bpy.props.IntProperty(name="Row Number",default=4)
	bpy.types.Scene.objectsetarrary_Marginw=bpy.props.FloatProperty(name="Width",default=1)
	bpy.types.Scene.objectsetarrary_Marginh=bpy.props.FloatProperty(name="Height",default=1)
	bpy.types.Scene.objectsetarrary_put_center=bpy.props.EnumProperty(
		name="Set Array Put Center", 
		items=[('original','Original','',0),('ground','Ground','',1)],
		default='original',
	)

	bpy.types.Scene.objectsetarrary_style=bpy.props.EnumProperty(
		name="Set Array Style", 
		items=[('Left','Left','',0),('Middle','Middle','',1),('Right','Right','',2)],
		default='Middle',
	)

	bpy.types.Scene.objectsetarrary_dirction=bpy.props.EnumProperty(
		name="Set Array Dirction", 
		items=[('Horizontal','Horizontal','',0),('Vertical','Vertical','',1)],
		default='Horizontal',
	)
	
	bpy.types.Scene.renametype=bpy.props.EnumProperty(
		name="MESH Type", 
		items=[('rename','RENAME','',0),('UseObjectName','UseObjectName','',1)],
		default='rename',
	)


	bpy.types.Scene.setname=bpy.props.StringProperty(name="")
	bpy.types.Scene.startnumber=bpy.props.IntProperty(name="Start Number",default=0)
	bpy.types.Scene.suffixzeros=bpy.props.IntProperty(name="Suffix Zeros",default=2)
	bpy.types.Scene.invertrename=bpy.props.BoolProperty(name="",default=False)

	bpy.types.Scene.renderangle = bpy.props.FloatProperty(
		name="", default=90.0)
	bpy.types.Scene.rendertimes = bpy.props.IntProperty(name="", default=0)
	bpy.types.Scene.rendertrue = bpy.props.BoolProperty(
		name="", default=False)
	
	bpy.types.Scene.setnormal=bpy.props.FloatProperty(name="",default=0.500,min=0.000,max=1.000,update=normal_update_func)
		
	bpy.types.Scene.batchsetmodifier=bpy.props.EnumProperty(
		name="batch set obj or collection", 
		items=[('obj1','Select_Object','',0),('Collection1','Select_Collection','',1)],
		default='obj1',
	)
	bpy.types.Scene.batchsetmodifier_getcollection=bpy.props.PointerProperty(name="", type=bpy.types.Collection)
	bpy.types.Scene.batchsetmodifier_getobj=bpy.props.PointerProperty(name="Target",  type=bpy.types.Object)

	bpy.types.Scene.objectbake=bpy.props.EnumProperty(
		name="Path Bake Array obj or collection", 
		items=[('obj1','Select_Object','',0),('Collection1','Select_Collection','',1)],
		default='obj1',
	)

	bpy.types.Scene.objectbake=bpy.props.EnumProperty(
		name="Path Bake Array obj or collection", 
		items=[('obj1','Select_Object','',0),('Collection1','Select_Collection','',1)],
		default='obj1',
	)
	bpy.types.Scene.objectbake_getcollection=bpy.props.PointerProperty(name="", type=bpy.types.Collection)
	bpy.types.Scene.objectbaketype=bpy.props.EnumProperty(
		name="Bake Type", 
		items=[('PAINTER','PAINTER','',0),('AO','AO','',1),('DIFFUSE','DIFFUSE','',2)],
		default='AO',
	)
	bpy.types.Scene.objectbakesize=bpy.props.EnumProperty(
		name="Texture Size", 
		items=[('256','256','',0),('512','512','',1),('1024','1024','',2),('2048','2048','',3),('4096','4096','',4)],
		default='1024',
	)
	bpy.types.Scene.objectbakelightsize=bpy.props.EnumProperty(
		name="Light Size", 
		items=[('16','16','',0),('32','32','',1),('64','64','',2),('128','128','',3),('256','256','',4),('512','512','',5),('1024','1024','',6)],
		default='32',
	)
	bpy.types.Scene.objectdiffuselight=bpy.props.EnumProperty(
		name="Diffuse Light", 
		items=[('Diffuse','Diffuse','',0),('NeedLight','NeedLight','',1)],
		default='Diffuse',
	)

	bpy.types.Scene.bakeanimation_obj=bpy.props.EnumProperty(
		name="bake obj or collection", 
		items=[('obj1','Select_Object','',0),('Collection1','Select_Collection','',1)],
		default='obj1',
	)

	bpy.types.Scene.bakeanimation_keytype=bpy.props.EnumProperty(
		name="keytype", 
		items=[('key1','Key_Transform','Key Transform',0),('key2','Key_Shape','Key Shape',1),('key3','Key_ALL','Key Transform and Key Shape',2)],
		default='key1',
	)

	bpy.types.Scene.bakeanimation_getcollection=bpy.props.PointerProperty(name="", type=bpy.types.Collection)

	bpy.types.Scene.setmatrial = bpy.props.PointerProperty(name="", type=bpy.types.Material)

	bpy.types.Scene.rendercollectionstr = bpy.props.PointerProperty(name="", type=bpy.types.Collection)

	from bpy.utils import register_class
	for cls in classes:
		register_class(cls)

	wm=bpy.context.window_manager
	active_keyconfig = wm.keyconfigs.active
	addon_keyconfig = wm.keyconfigs.addon
	kc=wm.keyconfigs.addon
	if kc:
		km=kc.keymaps.new(name="3D View",space_type='VIEW_3D')
		kmi=km.keymap_items.new("my_operator.creatretopo","T","PRESS",ctrl=True,shift=True)
		bgm_addon_keymaps.append((km,kmi))

		km=kc.keymaps.new(name="3D View",space_type='VIEW_3D')
		kmi=km.keymap_items.new("my_operator.bgmimportfbx","I","PRESS",ctrl=True,shift=True)
		bgm_addon_keymaps.append((km,kmi))

		km=kc.keymaps.new(name="3D View",space_type='VIEW_3D')
		kmi=km.keymap_items.new("my_operator.bgmexportfbxnew","E","PRESS",ctrl=True,shift=True)
		bgm_addon_keymaps.append((km,kmi))

def unregister():
	#del bpy.types.Scene.spmeshseleted
	#del bpy.tpyes.Scene.spmeshudmi
	del bpy.types.Scene.fbxcommonname
	del bpy.types.Scene.fbxsetcenter
	del bpy.types.Scene.Keep_Vert_Order
	del bpy.types.Scene.Use_Object_name
	
	del bpy.types.Scene.objectbake
	del bpy.types.Scene.objectbake_getcollection
	del bpy.types.Scene.objectbakesize
	del bpy.types.Scene.objectbakelightsize
	del bpy.types.Scene.objectbaketype

	del bpy.types.Scene.objectsetarrary
	del bpy.types.Scene.objectsetarrary_getcollection
	del bpy.types.Scene.objectsetarrary_mode
	del bpy.types.Scene.objectsetarrary_put_center
	del bpy.types.Scene.objectsetarrary_Number
	del bpy.types.Scene.objectsetarrary_Marginw
	del bpy.types.Scene.objectsetarrary_Marginh
	del bpy.types.Scene.objectsetarrary_dirction

	del bpy.types.Scene.renametype

	del bpy.types.Scene.renderangle
	del bpy.types.Scene.rendertimes
	del bpy.types.Scene.rendertrue
  

	del bpy.types.Scene.setmatrial

	del bpy.types.Scene.batchsetmodifier
	del bpy.types.Scene.batchsetmodifier_getcollection
	del bpy.types.Scene.batchsetmodifier_getobj

	del bpy.types.Scene.rendercollectionstr
	del bpy.types.Scene.setname
	
	del bpy.types.Scene.bakeanimation_obj
	del bpy.types.Scene.bakeanimation_getcollection
	del bpy.types.Scene.bakeanimation_keytype

	#del bpy.types.Scene.bakeanimation_keyTrantype

	del bpy.types.Scene.startnumber
	del bpy.types.Scene.suffixzeros
	del bpy.types.Scene.invertrename
	# try: bpy.utils.unregister_module(__name__)
	# except: traceback.print_exc()
	# #print("Unregistered {}".format(bl_info["name"]))
	from bpy.utils import unregister_class
	for cls in reversed(classes):
		unregister_class(cls)
	for km,kmi in bgm_addon_keymaps:
		km.keymap_items.remove(kmi)
	bgm_addon_keymaps.clear()
