import bpy
import bmesh

class bgmcreatretopo(bpy.types.Operator):
    bl_idname = "my_operator.creatretopo"
    bl_label = "Creat Topo Object"
    bl_description = "Please Select Topo object!!!"
    bl_options = {"REGISTER",'UNDO'}
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context): 
        bpy.ops.object.mode_set(mode='OBJECT')
        selected_objects = bpy.context.selected_objects 
        # for o in selected_objects:
        if len(selected_objects)<1:
            self.report({'ERROR'},"Please Select One Topo Object!")
        if len(selected_objects)>1:
            self.report({'ERROR'},"Please Select One Topo Object,Don`t Select too much!")
        if len(selected_objects)==1:
            if selected_objects[0].type!='MESH':
               self.report({'ERROR'},"Please Select Topo Object,Not other Type Object!") 
            if selected_objects[0].type == 'MESH':
                bpy.ops.mesh.primitive_plane_add(size=2, enter_editmode=False, align='WORLD', location=(1.21586, 6.31622, 2.89105), scale=(1, 1, 1))
                topoobj=bpy.context.view_layer.objects.active
                topoobj.name=selected_objects[0].name+"_Topo"
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.delete(type='VERT')
                bpy.context.scene.tool_settings.snap_elements = {'FACE'}
                bpy.context.scene.tool_settings.use_snap = True
                topoobj.modifiers.new(name='Shrinkwrap',type='SHRINKWRAP')
                topoobj.modifiers["Shrinkwrap"].target = selected_objects[0]
                topoobj.modifiers["Shrinkwrap"].wrap_mode = 'ABOVE_SURFACE'
                bpy.ops.wm.tool_set_by_id(name="builtin.poly_build")
                bpy.context.object.show_in_front = True
                bpy.context.space_data.shading.show_backface_culling = True


        return {"FINISHED"}
