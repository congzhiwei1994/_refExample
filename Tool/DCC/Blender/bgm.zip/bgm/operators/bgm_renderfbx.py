import bpy
import os
import math

def createrFolder(path):
    folder = os.path.exists(path)
    if folder==False:
        os.makedirs(path)
    return path
class bgmrender(bpy.types.Operator):
    bl_idname = "my_operator.bgamemanagerrender"
    bl_label = "Bgmrender"
    bl_description = ""
    bl_options = {"REGISTER"}

    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context): 
        rendangle=bpy.context.scene.renderangle
        rendtimes=bpy.context.scene.rendertimes
        rendertrue=bpy.context.scene.rendertrue
        pointalign=bpy.context.scene.tool_settings.use_transform_pivot_point_align
        pointtrans=bpy.context.scene.tool_settings.transform_pivot_point
        cursorloc=bpy.context.scene.cursor.location
        if bpy.data.filepath=="":
            self.report({'ERROR'},"Please Save Blender File!")
            return {"FINISHED"}

        #filepath="\\".join(bpy.data.filepath.split("\\")[0:-1]) 
        imgfilepath=createrFolder(bpy.data.filepath.split('.')[0]+"_BGM_Rander\\")
        try:
            bpy.context.scene.rendercollectionstr.name
        except:   
            self.report({'ERROR'},"Please Select Collection to the 'Re Collection'!")
            return {"FINISHED"}
            
        collstr=bpy.context.scene.rendercollectionstr.name
        col=bpy.data.collections[collstr]
        if len(col.objects)==0 :
            self.report({'ERROR'},"Please input Collection Name to the 'Re Collection'!")
            return {'FINISHED'}
        if len(col.objects)!=0:
            for i in col.objects:
                i.hide_viewport=True
                i.hide_render=True
            for i in col.objects:
                i.hide_render=False
                i.hide_viewport=False 
                bpy.context.scene.render.film_transparent = True
                
                if rendtimes==0:
                    if rendertrue==True:
                        
                        start=i.animation_data.action.frame_range[0]
                        end=i.animation_data.action.frame_range[1]

                        for k in range(int(start),int(end)):
                            bpy.context.scene.frame_current=k
                            filepath = imgfilepath+"\\"+i.name+"_f_"+str(k)+".png" # specify outout filepath here
                            rendandsave(filepath)
                    if rendertrue==False:
                        filepath = imgfilepath+"\\"+i.name+".png" # specify outout filepath here
                        rendandsave(filepath)
                if rendtimes!=0:
                    bpy.context.scene.camera.select_set(state=True)
                    oldangel=bpy.context.scene.camera.rotation_euler
                    oldtrans=bpy.context.scene.camera.location
                    n=0
                    for r in range(rendtimes+1):
                        start=i.animation_data.action.frame_range[0]
                        end=i.animation_data.action.frame_range[1]
                        rot=rendangle*n
                        if rendertrue==True:
                            for k in range(int(start),int(end)):
                                bpy.context.scene.frame_current=k
                                filepath = imgfilepath+"\\"+i.name+"_"+str('%.0f' % rot)+"_f_"+str(k)+".png" # specify outout filepath here
                                rendandsave(filepath)
                            
                        if rendertrue==False:
                            filepath = imgfilepath+"\\"+i.name+"_"+str('%.0f' % rot)+".png" # specify outout filepath here
                            rendandsave(filepath)

                        n+=1
                        bpy.ops.view3d.snap_cursor_to_center()
                        bpy.context.scene.tool_settings.transform_pivot_point = 'CURSOR'
                        bpy.context.scene.tool_settings.use_transform_pivot_point_align = False
                        bpy.ops.transform.rotate(value=rendangle*(math.pi/180), orient_axis='Z', orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(False, False, True), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
                    for rot in range(rendtimes+1):
                        bpy.ops.transform.rotate(value=-rendangle*(math.pi/180), orient_axis='Z', orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(False, False, True), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)
                    bpy.context.scene.camera.location=oldtrans
                    bpy.context.scene.camera.select_set(state=False)
               
                    
                i.hide_viewport=True
                i.hide_render=True
            
            bpy.context.scene.cursor.location=cursorloc
            bpy.context.scene.tool_settings.use_transform_pivot_point_align=pointalign
            bpy.context.scene.tool_settings.transform_pivot_point=pointtrans 
            for i in col.objects:
                i.hide_viewport=False
                i.hide_render=False
            os.system("start explorer "+imgfilepath)  

        
        return {"FINISHED"}



def rendandsave(filepath):
    img = bpy.data.images['Render Result'] # pick an image datablock
    #bpy.ops.render.render(use_viewport=True)
    #rendertrue=bpy.context.scene.rendertrue
    # if rendertrue==False:
    #     bpy.ops.render.render(use_viewport=True)
    # else:
    #     bpy.ops.render.render(animation=True, use_viewport=True) 
    bpy.ops.render.render(use_viewport=True)
    # Store current render settings
    settings = bpy.context.scene.render.image_settings
    format = settings.file_format
    mode = settings.color_mode
    depth = settings.color_depth

    # Change render settings to our target format
    settings.file_format = 'PNG'
    settings.color_mode = 'RGBA'
    settings.color_depth = '8'

    # Save image to TIF, this does NOT render anything!
    # It only means that the save command will use the current scene's render settings.
    img.save_render(filepath)

    # Restore previous render settings
    settings.file_format = format
    settings.color_mode = mode
    settings.color_depth = depth


def change_nal_tracks_name():
    for o in bpy.context.collection.objects:
        try:
            o.animation_data.nla_tracks
            for i in o.animation_data.nla_tracks:
                if len(i.strips)==0:
                    i.select=True
                    i.lock=False
                    i.mute=True
                    bpy.context.collection.objects[1].animation_data.nla_tracks.remove(i)
                if len(i.strips)==1:
                    i.name=i.strips[0].name
        except:
            pass
