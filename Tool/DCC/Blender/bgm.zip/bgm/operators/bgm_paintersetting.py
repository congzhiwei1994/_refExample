import bpy
import os

class bgmpaintersetting(bpy.types.Operator):
    bl_idname = "my_operator.bgmpaintersetting"
    bl_label = "Bgmpaintersetting"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}

    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.context.scene.render.engine = 'BLENDER_EEVEE'
        bpy.context.scene.eevee.taa_render_samples = 1024
        bpy.context.scene.eevee.taa_samples = 1024
        #bpy.context.scene.view_settings.view_transform = 'Standard'


        objlist=bpy.context.selected_objects
        for i in objlist:
            if len(i.material_slots)==0:
                bpy.ops.object.material_slot_add()
                try:
                    mat1=bpy.data.materials[i.name]
                    i.material_slots[0].material=mat1
                except:
                    mat1=bpy.data.materials.new(i.name)
                    mat1.use_nodes = True
                    i.material_slots[0].material=mat1
            if len(i.material_slots)>0:
                try:
                     i.material_slots[0].material.name
                except:
                    try:
                        mat1=bpy.data.materials[i.name]
                        i.material_slots[0].material=mat1
                    except:
                        mat1=bpy.data.materials.new(i.name)
                        mat1.use_nodes = True
                        i.material_slots[0].material=mat1



            mat=i.material_slots[0].material
            mat.use_nodes = True
            mat.blend_method = 'HASHED'
            mat.use_backface_culling = False


            nodes=mat.node_tree.nodes
            if nodes.get("Principled BSDF") is None:
                bsdf=nodes.new(type='ShaderNodeBsdfPrincipled')
                
            else:
                bsdf=nodes.get("Principled BSDF")
            bsdf.location=(300,200)
            bsdf.inputs['Metallic'].default_value=0.0
            bsdf.inputs['Specular'].default_value=0.0

            if nodes.get('Image Texture')  is None:
                image=nodes.new(type="ShaderNodeTexImage")
                bpy.ops.image.new(name=i.name,color=(0.2,0.2,0.2,1),alpha=True)
                image.image=bpy.data.images[i.name]
            else:
                image=nodes.get('Image Texture')
                
                
            image.location=(80,360)   

            if nodes.get("Material Output") is None:
                matout=nodes.new(type="ShaderNodeOutputMaterial")
                
            else:
                matout=nodes.get("Material Output")
            matout.location=(450,160)  

            links=mat.node_tree.links
            links.new(image.outputs[0],bsdf.inputs[0])
            links.new(image.outputs[0],bsdf.inputs[17])
            links.new(image.outputs[1],bsdf.inputs[18])
            links.new(bsdf.outputs[0],matout.inputs[0])

        bpy.context.scene.view_settings.exposure = 0
        bpy.context.scene.view_settings.use_curve_mapping = False
        bpy.context.scene.view_settings.gamma = 1
        try:
            bpy.data.worlds['World'].node_tree.nodes["Background"].inputs[0].default_value = (0, 0, 0, 1)
        except:
            pass

        for i in bpy.data.objects:
            if bpy.data.objects[i.name].type=="LIGHT":
                print(i.name)
                try:
                    bpy.data.objects[i.name].hide_viewport=True
                    bpy.data.objects[i.name].hide_render=True 
                except:
                    a=1 
            


        for area in bpy.data.workspaces[bpy.context.window.workspace.name].screens[0].areas:
            if area.type == 'VIEW_3D':
                for spaces in area.spaces:
                    if spaces.type == 'VIEW_3D':
                        spaces.shading.type = 'RENDERED'

        bpy.data.worlds["World"].node_tree.nodes["Background"].inputs[0].default_value = (0.178338, 0.178338, 0.178338, 1)

        return {"FINISHED"}

class bgmpainterbaketype(bpy.types.Operator):
    bl_idname = "my_operator.bgmpainterbaketype"
    bl_label = "Bgmpaintersetting"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        objlist=bpy.context.selected_objects

        bakesize=int(bpy.context.scene.objectbakelightsize)
        baketype=bpy.context.scene.objectbaketype

        objs = []
        ObjorColl=bpy.context.scene.objectbake
        if ObjorColl == "obj1":
            objs = bpy.context.selected_objects
            if len(objs) == 0:
                self.report({'ERROR'}, "Please Select Objects to Bake'!")
                return {"FINISHED"}

        if ObjorColl == "Collection1":
            get_collection = bpy.context.scene.objectsetarrary_getcollection
            objs=bpy.data.collections[get_collection.name].objects
            if len(objs) == 0:
                self.report({'ERROR'}, "Please Select Collection to Bake!")
                return {"FINISHED"}
        renderops=bpy.context.scene.render.engine
        bpy.context.scene.render.engine = 'CYCLES'
        

        bpy.context.scene.world.light_settings.use_ambient_occlusion = True
        bpy.context.scene.render.bake.use_selected_to_active = False
        

        if baketype=="AO":
            for o in objs:
                obj=o
                try:
                    bpy.data.images[obj.name+"_AO"]
                except:
                    bpy.ops.image.new(name=obj.name+"_AO")

                if len(obj.material_slots)==0:
                    bpy.ops.object.material_slot_add()
                    
                if obj.material_slots[0].material is None:
                    material=bpy.ops.material.new()
                    obj.material_slots[0].material=material
                    
                obj.material_slots[0].material.use_nodes=True
                nodes=obj.material_slots[0].material.node_tree.nodes

                if nodes.get('Image Texture')  is None:
                    image=nodes.new(type="ShaderNodeTexImage")
                    image.image=bpy.data.images[obj.name+"_AO"]
                else:
                    image=nodes.get('Image Texture')
                    image.image=bpy.data.images[obj.name+"_AO"]


                
                bpy.context.scene.cycles.bake_type = 'AO'
                bpy.context.scene.cycles.samples = bakesize
                

                bpy.ops.object.bake(type='AO')
        if baketype=="DIFFUSE":
            bpy.context.scene.cycles.bake_type = 'DIFFUSE'
            needlight=bpy.context.scene.objectdiffuselight
            if needlight=="Diffuse":
                bpy.context.scene.render.bake.use_pass_color = True
                bpy.context.scene.render.bake.use_pass_indirect = False
                bpy.context.scene.render.bake.use_pass_direct = False
            if needlight=="NeedLight":
                bpy.context.scene.render.bake.use_pass_color = True
                bpy.context.scene.render.bake.use_pass_indirect = True
                bpy.context.scene.render.bake.use_pass_direct = True
            for o in objs:
                obj=o
                try:
                    bpy.data.images[obj.name+"_Diffuse"]
                except:
                    bpy.ops.image.new(name=obj.name+"_Diffuse")
                    
                if len(obj.material_slots)==0:
                    bpy.ops.object.material_slot_add()
                    
                if obj.material_slots[0].material is None:
                    material=bpy.ops.material.new()
                    obj.material_slots[0].material=material
                    
                obj.material_slots[0].material.use_nodes=True
                nodes=obj.material_slots[0].material.node_tree.nodes

                if nodes.get('Image Texture')  is None:
                    image=nodes.new(type="ShaderNodeTexImage")
                    image.image=bpy.data.images[obj.name+"_Diffuse"]
                else:
                    image=nodes.get('Image Texture')
                    image.image=bpy.data.images[obj.name+"_Diffuse"]

                
                bpy.context.scene.cycles.samples = bakesize
                bpy.ops.object.bake(type='DIFFUSE')

        if baketype=="PAINTER":
            path=os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
            blendfile=path+"/resource/BGM.blend"
            section="/Material/"
            mat="Painter"
            filepath  =blendfile
            directory = blendfile + section
            filename  = "BGM.blend"
            bpy.ops.wm.append(directory=directory,filepath=filename,filename=mat)
            
            for o in objs:

                obj=o
                if len(obj.material_slots)==0:
                    bpy.ops.object.material_slot_add()
                try:
                    bpy.data.materials[obj.name+"_BGM"]
                except:
                    mat=bpy.data.materials.new(name=obj.name+"_BGM")
                    mat.use_nodes = True

                obj.material_slots[0].material=bpy.data.materials["Painter"]

                try:
                    bpy.data.images[obj.name+"_Painter"]
                except:
                    bpy.ops.image.new(name=obj.name+"_Painter")
                    
                obj.material_slots[0].material.use_nodes=True
                nodes=obj.material_slots[0].material.node_tree.nodes

 
                image=nodes.get('Image Texture')
                image.image=bpy.data.images[obj.name+"_Painter"]
                
                bpy.context.scene.cycles.bake_type = 'EMIT'
                bpy.context.scene.render.bake.use_pass_color = True
                bpy.context.scene.render.bake.use_pass_indirect = False
                bpy.context.scene.render.bake.use_pass_direct = False
                bpy.context.scene.cycles.samples = bakesize
                if len(bpy.context.selected_objects)==0:
                    o.select_set(state=True)
                
                bpy.ops.object.bake(type='EMIT')
                o.select_set(state=False)
                obj.active_material_index=0
                obj.material_slots[0].material=bpy.data.materials[obj.name+"_BGM"]
                newnodes=bpy.context.active_object.material_slots[0].material.node_tree.nodes
                if newnodes.get('Image Texture')  is None:
                    image=newnodes.new(type="ShaderNodeTexImage")
                    image.image=bpy.data.images[obj.name+"_Painter"]
                else:
                    image=newnodes.get('Image Texture')
                    image.image=bpy.data.images[obj.name+"_Painter"]
                
                links=bpy.context.active_object.material_slots[0].material.node_tree.links
                bsdf=newnodes.get("Principled BSDF")
                links.new(image.outputs[0],bsdf.inputs[0])
                

        bpy.context.scene.render.engine=renderops
        
        if len(objlist)>0:
            bpy.ops.object.select_all(action='TOGGLE')
        for o in objlist:
            o.select_set(state=True)


        
        return {"FINISHED"}

