import bpy
class bgmuseobjectname(bpy.types.Operator):
    bl_idname = "my_operator.bgamemanageruseobjectname"
    bl_label = "Bgmuseobjectname"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context): 
        objlist=bpy.context.selected_objects
        if len(objlist)==0:
            self.report({'ERROR'},"Please Select Object and Set Name!")
            return {"FINISHED"}
        else:
            for obj in objlist:
                if obj.type=="MESH":
                    datainfo=obj.data
                    datainfo.name=obj.name
                    n=0
                    for mat in datainfo.materials:
                        if len(datainfo.materials)>0:
                            if mat is None:
                                datainfo.materials[0]= bpy.data.materials.new(name="Material")
                                datainfo.materials[0].name=obj.name
                            else:
                                if mat.name!="":
                                    if mat.name!=datainfo.name:
                                        newmat=mat.copy()
                                        if len(datainfo.materials)>=2:
                                            newmat.name=datainfo.name+"_"+str(n)
                                            datainfo.materials[n]=newmat
                                            n=n+1
                                        if len(datainfo.materials)==1:
                                            newmat.name=datainfo.name
                                            datainfo.materials[n]=newmat
                    # if len(datainfo.materials)==1:
                    #     if mat.name!="":
                    #         if mat.name!=datainfo.name:
                    #             newmat=mat.copy()
                    #             mat=newmat
                    #             mat.name=datainfo.name
            
                
            
        return {"FINISHED"}

class bgmsetname(bpy.types.Operator):
    bl_idname = "my_operator.bgamemanagersetname"
    bl_label = "Bgmsetname"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}

    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context): 
        setname=bpy.context.scene.setname
        startnumber=bpy.context.scene.startnumber
        suffixzeros=bpy.context.scene.suffixzeros
        invertname=bpy.context.scene.invertrename

        print(setname)
        
        objlist=bpy.context.selected_objects
        if setname=="" and len(objlist)==0:
            self.report({'ERROR'},"Please Select Object and Set Name!")
            return {"FINISHED"}
        else:
            
            if invertname==True:
                a=startnumber+len(objlist)-1
                for objs in objlist:
                    objs.name=setname+suffixzero(suffixzeros,a)
                    a=a-1
                    
            if invertname==False:
                a=startnumber
                for objs in objlist:
                    objs.name=setname+suffixzero(suffixzeros,a)
                    a=a+1

                    
        return {"FINISHED"}

def suffixzero(suffixzeros,objnumb):
    listnumb=[]
    returenumb=""
    for i in str(objnumb):
        listnumb.append(str(i))
    listnumb.reverse()
    print(listnumb)
    if len(listnumb)>=suffixzeros:
        numb=listnumb[0:suffixzeros]
    if len(listnumb)<suffixzeros:
        numb=listnumb[0:len(listnumb)]
    numb.reverse()
    for n in numb:
        returenumb+=n
    if len(listnumb)<suffixzeros:
        returenumb="0"*(suffixzeros-len(listnumb))+returenumb
    return(returenumb)
        