import bpy

class bgmsettingmat(bpy.types.Operator):
    bl_idname = "my_operator.bgmsettingmat"
    bl_label = "Bgmrender"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}

    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context): 
        col=bpy.data.collections["BGM_FBX"]
        if len(col.objects)==0 :
            self.report({'ERROR'},"Please Drag Collection to the 'Re Collection'!")
            return {'FINISHED'}
        if len(col.objects)!=0:
            for i in col.objects:
                bpy.data.objects[i.name].select_set(state=True)
                mats=bpy.context.active_object.data.materials
                for m in mats:
                    mat=m.node_tree.nodes['Principled BSDF']
                    mat.inputs['Metallic'].default_value=1.0
                    mat.inputs['Specular'].default_value=0.2
                    mat.inputs['Roughness'].default_value=0.65
                bpy.data.objects[i.name].select_set(state=False)
        return {"FINISHED"}