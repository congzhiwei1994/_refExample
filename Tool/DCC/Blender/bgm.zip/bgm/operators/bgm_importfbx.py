import bpy
import os,subprocess,re,shutil


# ImportHelper is a helper class, defines filename and
# invoke() function which calls the file selector.
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty,CollectionProperty
from bpy.types import Operator
#-----Creater Folder----
def createrFolder(path):
    folder = os.path.exists(path)
    if folder==False:
        os.makedirs(path)
    return path

def find_collection(context, item):
    collections = item.users_collection
    if len(collections) > 0:
        return collections[0]
    return context.scene.collection

def make_collection(collection_name, parent_collection):
    if collection_name in bpy.data.collections: # Does the collection already exist?
        return bpy.data.collections[collection_name]
    else:
        if bpy.data.collections.find(collection_name)==-1:
            new_collection = bpy.data.collections.new(collection_name)
            parent_collection.link(new_collection) # Add the new collection under a parent
        return new_collection
    


class ImportFbxData(Operator, ImportHelper):
    """This appears in the tooltip of the operator and in the generated docs"""
    bl_idname = "my_operator.bgmimportfbx"  # important since its how bpy.ops.import_test.some_data is constructed
    bl_label = "Import MESH Files"
    # ImportHelper mixin class uses this

    filename_ext = ".fbx"
    filter_glob = StringProperty(
                    default="*.fbx",
                    options={'HIDDEN'},
                    )


    files: CollectionProperty(
            name="File Path",
            type=bpy.types.OperatorFileListElement,
            )

    def draw(self, context):
            layout = self.layout
            scene = context.scene
            layout.label(text="Import MESH TYPE")
            layout.prop(scene, "meshtype",expand=True)
            if bpy.context.scene.meshtype =='fbx':
                self.bl_label="Import FBX Files"
                
            else:
                self.bl_label="Import OBJ Files"
                row = layout.row(align=True)
                row.label(text="Keep Vert Order:")
                rowx = row.row(align=True)
                rowx.scale_x = 1
                rowx.scale_y = 1.0
                rowx.prop(scene, "Keep_Vert_Order")
                
            
    def execute(self, context):
        if bpy.context.scene.meshtype =='fbx': 
            collection_name="BGM_FBX"
            if bpy.data.collections.find(collection_name)==-1:        
                myCol = bpy.data.collections.new(collection_name)
                bpy.context.scene.collection.children.link(myCol)
                
            fbxconvertexe=os.path.split(os.path.realpath(__file__))[0]+"\FbxFormatConverter.exe"
            if self.files:
                for f in self.files:
                    
                    if f.name.find(".fbx") and  (f.name.split(".")[0] in bpy.data.objects)==False:
                        subpath="\\".join(self.filepath.split("\\")[0:-1])+"\\"+f.name
                        zw = re.compile(u'[\u4e00-\u9fa5]+')
                        if zw.search(subpath):
                            directory=os.path.abspath(os.path.dirname(os.path.split(os.path.realpath(__file__))[0]))
                            bl2sppath=createrFolder(directory+"\\bgm2FBX\\")
                            subpathnew=bl2sppath+"\123.fbx"
                            subpathnew1=bl2sppath+"\1234.fbx"
                            shutil.copyfile(subpath,subpathnew) 
                            asci=subprocess.Popen([fbxconvertexe,'-q',subpathnew],stdout = subprocess.PIPE)
                            asciinfo=asci.communicate()[0]
                            print(asciinfo)
                            if b'- ascii' in asciinfo:
                                asciconverinfo=subprocess.call([fbxconvertexe,'-c',subpathnew,'-o',subpathnew1,'-binary'],stdout = subprocess.PIPE)
                                try:
                                    bpy.ops.import_scene.fbx(filepath=subpathnew1)
                                    
                                except :
                                    self.report({'ERROR'},"Can`t import the FBX Path:"+subpath)
                                os.remove(subpathnew)
                                os.remove(subpathnew1)
                            else:
                                bpy.ops.import_scene.fbx(filepath=subpathnew)
                                # os.remove(subpathnew)
                        else:
                            newpath="\\".join(self.filepath.split("\\")[0:-1])+"\\bgm_convert_"+f.name
                            asci=subprocess.Popen([fbxconvertexe,'-q',subpath],stdout = subprocess.PIPE)
                            asciinfo=asci.communicate()[0]
                            print(asciinfo)
                            if b'- ascii' in asciinfo:
                                asciconverinfo=subprocess.call([fbxconvertexe,'-c',subpath,'-o',newpath,'-binary'],stdout = subprocess.PIPE)
                                try:
                                    bpy.ops.import_scene.fbx(filepath=newpath)
                                except :
                                    self.report({'ERROR'},"Can`t import the FBX Path:"+subpath)
                                
                                os.remove(newpath)
                            else:
                                bpy.ops.import_scene.fbx(filepath=subpath)
                        for obj in bpy.context.selected_objects:
                            fbx_collection = find_collection(bpy.context, obj)
                            new_collection = make_collection(collection_name, bpy.data.collections[collection_name].objects)
                            try:
                                new_collection.objects.link(obj)  
                                fbx_collection.objects.unlink(obj)
                            except:
                                pass 
        else:
            collection_name="BGM_FBX"
            if bpy.data.collections.find(collection_name)==-1:        
                myCol = bpy.data.collections.new(collection_name)
                bpy.context.scene.collection.children.link(myCol)
            if self.files:
            
                for f in self.files:
                    if f.name.find(".obj") and  (f.name.split(".")[0] in bpy.data.objects)==False: 
                        subpath="\\".join(self.filepath.split("\\")[0:-1])+"\\"+f.name
                        if bpy.context.scene.Keep_Vert_Order==True:
                            bpy.ops.import_scene.obj(filepath=subpath,split_mode="OFF")
                        if bpy.context.scene.Keep_Vert_Order==False:
                            bpy.ops.import_scene.obj(filepath=subpath)
                            
                        for obj in bpy.context.selected_objects:
                            fbx_collection = find_collection(bpy.context, obj)
                            new_collection = make_collection(collection_name, bpy.data.collections[collection_name].objects)
                            try:
                                new_collection.objects.link(obj)  
                                fbx_collection.objects.unlink(obj)
                            except:
                                pass

        return {'FINISHED'}
class ImportobjData(Operator, ImportHelper):
    """This appears in the tooltip of the operator and in the generated docs"""
    bl_idname = "my_operator.bgmimportobj"  # important since its how bpy.ops.import_test.some_data is constructed
    bl_label = "Import OBJ Files"
    # ImportHelper mixin class uses this

    filename_ext = ".obj"
    filter_glob = StringProperty(
                    default="*.obj",
                    options={'HIDDEN'},
                    )
    files: CollectionProperty(
            name="File Path",
            type=bpy.types.OperatorFileListElement,
            )

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        self.bl_label="Import OBJ Files"
        row = layout.row(align=True)
        row.label(text="Keep Vert Order:")
        rowx = row.row(align=True)
        rowx.scale_x = 1
        rowx.scale_y = 1.0
        rowx.prop(scene, "Keep_Vert_Order")
                
    def execute(self, context):
        
        collection_name="BGM_FBX"
        if bpy.data.collections.find(collection_name)==-1:        
            myCol = bpy.data.collections.new(collection_name)
            bpy.context.scene.collection.children.link(myCol)
        if self.files:
        
            for f in self.files:
                if f.name.find(".obj") and  (f.name.split(".")[0] in bpy.data.objects)==False: 
                    subpath="\\".join(self.filepath.split("\\")[0:-1])+"\\"+f.name
                    if bpy.context.scene.Keep_Vert_Order==True:
                        bpy.ops.import_scene.obj(filepath=subpath,split_mode="OFF")
                    if bpy.context.scene.Keep_Vert_Order==False:
                        bpy.ops.import_scene.obj(filepath=subpath)
                        
                    for obj in bpy.context.selected_objects:
                        fbx_collection = find_collection(bpy.context, obj)
                        new_collection = make_collection(collection_name, bpy.data.collections[collection_name].objects)
                        try:
                            new_collection.objects.link(obj)  
                            fbx_collection.objects.unlink(obj)
                        except:
                            pass
                    
        return {'FINISHED'}

