import bpy
import bmesh

class bgmexportbakeanimation(bpy.types.Operator):
    bl_idname = "my_operator.bakeanimation"
    bl_label = "Bgmbakeanimation"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}

    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context): 
        start = bpy.context.scene.frame_start
        end = bpy.context.scene.frame_end
        get_obj=bpy.context.scene.bakeanimation_obj
        keytype=bpy.context.scene.bakeanimation_keytype
        
        objs=[]
        if get_obj=='obj1':
            objs=bpy.context.selected_objects
            if len(objs)==0:
                self.report({'ERROR'},"Please Select Mesh Object!")
                return {"FINISHED"}
        if get_obj=='Collection1':
            get_collection=bpy.context.scene.bakeanimation_getcollection
            #objs=get_collection.objects
            for o in bpy.data.collections[get_collection.name].objects:
                objs.append(o)
            if len(objs)==0:
                self.report({'ERROR'},"Please Select Collection!")
                return {"FINISHED"}
        #action=bpy.data.actions.new(name="BGM")

        objlist=bpy.context.selected_objects
        if len(objlist)>0:
            bpy.ops.object.select_all(action='TOGGLE')
        for obj in objs:
    
            if (keytype=="key1"):
 
                keytransfrom(obj,start,end)
                
            if (keytype=="key2"):

                keyshaper(obj,start,end)
                
            if (keytype=="key3"):    
   
                keytransfrom(obj,start,end)
                keyshaper(obj,start,end)

        for obj in objlist:
            obj.select_set(state=True)

            return {"FINISHED"}



def insert_keyframe(sk, f):
    sk.keyframe_insert("value", frame=f-1)
    sk.keyframe_insert("value", frame=f+1)
    sk.value = 1.0
    sk.keyframe_insert("value", frame=f)

# def insert_data(obj,action,start,end,strvalue):
#     data_path = strvalue
#     for axis in [0, 1, 2]:
#         fc = action.fcurves.new(data_path, index=axis)
#         fc.keyframe_points.add(count=(end-start)*3)
#         for f in range(start, end+1):
#             bpy.context.scene.frame_current=f
#             if strvalue=="location":
#                 fc.keyframe_points[f].co = (f, bpy.context.object.location[axis])
#             if strvalue=="scale":
#                 fc.keyframe_points[f].co = (f, bpy.context.object.scale[axis])
#             if strvalue=="rotation_euler":
#                 fc.keyframe_points[f].co = (f, bpy.context.object.rotation_euler[axis])
#         strvalue=""

def keytransfrom(obj,start,end): 
    bpy.data.objects[obj.name].select_set(state=True)
    if len(obj.modifiers)>0:
        for i in obj.modifiers:
            try:
                override = {'blend_data': bpy.data,'scene': bpy.context.scene, 'active_object': obj,'point_cache': i.point_cache}
                bpy.ops.ptcache.bake(override,bake=True)
            except:
                pass

    for f in range(start, end+1):
        bpy.context.scene.frame_current=f

        bpy.ops.anim.keyframe_insert_menu(type='BUILTIN_KSI_VisualLoc')
        bpy.ops.anim.keyframe_insert_menu(type='BUILTIN_KSI_VisualRot')
        bpy.ops.anim.keyframe_insert_menu(type='BUILTIN_KSI_VisualScaling')

    bpy.data.objects[obj.name].select_set(state=False)

def keyshaper(obj,start,end):
    print(obj.name)
    bpy.data.objects[obj.name].select_set(state=True)
    obj.shape_key_add(name="Basis", from_mix=False)  
    meshes = []
    print(start,end)

    if len(obj.modifiers)>0:
        for i in obj.modifiers:
            try:
                override = {'blend_data': bpy.data,'scene': bpy.context.scene, 'active_object': obj,'point_cache': i.point_cache}
                bpy.ops.ptcache.bake(override,bake=True)
            except:
                pass
            
    
    for f in range(start, end+1):
        
        bpy.context.scene.frame_set(f)
        depsgraph = bpy.context.evaluated_depsgraph_get()
        object_eval = obj.evaluated_get(depsgraph)

        meshes.append(object_eval)
        print(object_eval.data.vertices[31].co)
        if f>start:
            
            key = obj.shape_key_add(name=str(f), from_mix=False)
            insert_keyframe(key, f)
            
            for vert_id in range(len(obj.data.vertices)):
                
                key.data[vert_id].co=object_eval.data.vertices[vert_id].co     
    bpy.data.objects[obj.name].select_set(state=False)
    meshes=[]

# for action in bpy.data.actions:
#     for fcurve in action.fcurves:
#         fcurve.keyframe_points.insert(1, fcurve.keyframe_points[0].co.y)

# import bpy
# action = bpy.data.actions.new("RandomScaleAction")
# data_path = "location"
# start = bpy.context.scene.frame_start
# end = bpy.context.scene.frame_end
# for o in bpy.context.selected_objects:
#     for axis in [0, 1, 2]:
#         fc = action.fcurves.new(data_path, index=0)
#         fc1 = action.fcurves.new(data_path, index=1)
#         fc2 = action.fcurves.new(data_path, index=2)
#         fc.keyframe_points.add((end-start)*2)
#         fc1.keyframe_points.add((end-start)*2)
#         fc2.keyframe_points.add((end-start)*2)
#         #for kfp in fc.keyframe_points:
#         a=1
#         for f in range(start, end+1):
            
#             bpy.context.scene.frame_current=f
#             bpy.ops.transform.translate()
#             fc.keyframe_points[a].co = (f, o.location[0])
#             fc1.keyframe_points[a].co = (f, o.location[1])
#             fc2.keyframe_points[a].co = (f, o.location[2])
#             a+=1