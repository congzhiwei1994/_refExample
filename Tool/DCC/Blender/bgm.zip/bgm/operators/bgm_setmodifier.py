import bpy

class bgmsetaddmodiifer(bpy.types.Operator):
    bl_idname = "my_operator.bgmsetaddmodiifer"
    bl_label = "Bgmaddmodiifer"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}

    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        getmodobj=bpy.context.scene.batchsetmodifier_getobj
        get_obj=bpy.context.scene.batchsetmodifier
        objlist=bpy.context.selected_objects
        objs=[]
        if get_obj=='obj1':
            objs=bpy.context.selected_objects
            if len(objs)==0:
                self.report({'ERROR'},"Please Select Mesh Object!")
                return {"FINISHED"}
        if get_obj=='Collection1':
            get_collection=bpy.context.scene.batchsetmodifier_getcollection
            #objs=get_collection.objects
            for o in bpy.data.collections[get_collection.name].objects:
                objs.append(o)
            if len(objs)==0:
                self.report({'ERROR'},"Please Select Collection!")
                return {"FINISHED"}
        if bpy.context.scene.batchsetmodifier_getobj==None:
            self.report({'ERROR'},"Please Select Target Object!")
            return {"FINISHED"}
        
        
        if len(objlist)>0:
            bpy.ops.object.select_all(action='TOGGLE')
        for obj in objs:
            
            try:
                obj.select_set(state=True)
                getmodobj.select_set(state=True)
                bpy.ops.object.make_links_data(type='MODIFIERS')
                obj.select_set(state=False)
                getmodobj.select_set(state=False)
            except:
                if len(bpy.context.selected_objects)>0:
                    bpy.ops.object.select_all(action='TOGGLE')
                
        
        for o in objs:
            obj.select_set(state=False)

        for o in objlist:
            o.select_set(state=True)
            

        return {"FINISHED"} 

class bgmsetapplymodiifer(bpy.types.Operator):
    bl_idname = "my_operator.bgmsetapplymodiifer"
    bl_label = "Bgmapplymodiifer"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}

    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        getmodobj=bpy.context.scene.batchsetmodifier_getobj
        get_obj=bpy.context.scene.batchsetmodifier
        objlist=bpy.context.selected_objects
        objs=[]
        if get_obj=='obj1':
            objs=bpy.context.selected_objects
            if len(objs)==0:
                self.report({'ERROR'},"Please Select Mesh Object!")
                return {"FINISHED"}
        if get_obj=='Collection1':
            get_collection=bpy.context.scene.batchsetmodifier_getcollection
            #objs=get_collection.objects
            for o in bpy.data.collections[get_collection.name].objects:
                objs.append(o)
            if len(objs)==0:
                self.report({'ERROR'},"Please Select Collection!")
                return {"FINISHED"}
        # if bpy.context.scene.batchsetmodifier_getobj==None:
        #     self.report({'ERROR'},"Please Select Target Object!")
        #     return {"FINISHED"}
        
        
        if len(objlist)>0:
            bpy.ops.object.select_all(action='TOGGLE')
        for obj in objs:
            
            try:
                obj.select_set(state=True)
                getmodobj.select_set(state=True)
                bpy.ops.object.make_links_data(type='MODIFIERS')
                obj.select_set(state=False)
                getmodobj.select_set(state=False)
            except:
                if len(bpy.context.selected_objects)>0:
                    bpy.ops.object.select_all(action='TOGGLE')
                
        
        for o in objs:
            for m in o.modifiers:
                try:
                    bpy.ops.object.modifier_apply(apply_as='DATA', modifier=m.name)
                except:
                    pass
            

        return {"FINISHED"} 



class bgmsetclearmodiifer(bpy.types.Operator):
    bl_idname = "my_operator.bgmclearsetmodiifer"
    bl_label = "Bgmclearmodiifer"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}

    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        getmodobj=bpy.context.scene.batchsetmodifier_getobj
        get_obj=bpy.context.scene.batchsetmodifier
        objlist=bpy.context.selected_objects
        objs=[]
        if get_obj=='obj1':
            objs=bpy.context.selected_objects
            if len(objs)==0:
                self.report({'ERROR'},"Please Select Mesh Object!")
                return {"FINISHED"}
        if get_obj=='Collection1':
            get_collection=bpy.context.scene.batchsetmodifier_getcollection
            #objs=get_collection.objects
            for o in bpy.data.collections[get_collection.name].objects:
                objs.append(o)
            if len(objs)==0:
                self.report({'ERROR'},"Please Select Collection!")
                return {"FINISHED"}
        if bpy.context.scene.batchsetmodifier_getobj==None:
            self.report({'ERROR'},"Please Select Target Object!")
            return {"FINISHED"}
        
        
        for o in objs:
            o.modifiers.clear()
        return {"FINISHED"} 