import bpy
import math

def getcenter(obj):
    o = obj
    vcos = [o.matrix_world @ v.co for v in o.data.vertices]
    def findCenter(l): return (max(l) + min(l)) / 2
    x, y, z = [[v[i] for v in vcos] for i in range(3)]
    center = [findCenter(axis) for axis in [x, y, z]]
    return center
def findcenter(obj):
    
    center=getcenter(obj)
    obj.location = (obj.location[0]-center[0],
                    (obj.location[1]-center[1]),
                    (obj.location[2]-center[2])+obj.dimensions.z/2)

def findcenterz(obj):
    center=getcenter(obj)
    z=(obj.location[2]-center[2])+obj.dimensions.z/2
    return z

class bgmsetarray(bpy.types.Operator):
    bl_idname = "my_operator.bgmsetarray"
    bl_label = "Bgmsetarraycenter"
    bl_description = ""
    bl_options = {"REGISTER", 'UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        ObjorColl = bpy.context.scene.objectsetarrary
        mode = bpy.context.scene.objectsetarrary_mode
        putcenter = bpy.context.scene.objectsetarrary_put_center

        #setstyle = bpy.context.scene.objectsetarrary_style
        dircction = bpy.context.scene.objectsetarrary_dirction
        rownum = bpy.context.scene.objectsetarrary_Number
        maginw = bpy.context.scene.objectsetarrary_Marginw
        maginh = bpy.context.scene.objectsetarrary_Marginh

        objs = []
        if ObjorColl == "obj1":
            objs = bpy.context.selected_objects
            print(len(objs))
            if len(objs) == 0:
                self.report({'ERROR'}, "Please Select Objects to Array'!")
                return {"FINISHED"}

        if ObjorColl == "Collection1":
            get_collection = bpy.context.scene.objectsetarrary_getcollection
            objs=bpy.data.collections[get_collection.name].objects
            if len(objs) == 0:
                self.report({'ERROR'}, "Please Select Collection!")
                return {"FINISHED"}
        if mode == "Center":
            if putcenter == "original":
                for o in objs:
                    o.location = (0, 0, 0)

            if putcenter == "ground":
                for o in objs:
                    findcenter(o)
        if mode == "Array":
            objsnum = len(objs)
            column = math.ceil(objsnum/rownum)
            res = objsnum % rownum
            widthlist = []
            heightlist = []
            n = 0
            objwidthlist=[]
            objheightlist=[]
            for o in objs:
                objwidthlist.append(o.dimensions[0])
                objheightlist.append(o.dimensions[1])
            
            for o in range(column-1):
                width = 0
                height = 0
                for r in range(rownum):
                    width += objs[o*rownum+r].dimensions[0]
                    
                    height += objs[o*rownum+r].dimensions[1]
                widthlist.append(width)
                
                heightlist.append(height)
                
                n += 1
            if res != 0:
                width = 0
                height = 0
                for i in range(res):
                    width += objs[(column-1)*rownum+i].dimensions[0]
                    
                widthlist.append(width)
                heightlist.append(height)
                #print("LIST",widthlist,heightlist)
    
            maxwidth = max(objwidthlist)*rownum+rownum*maginw
            maxheight = max(objheightlist)+maginh
            #print("MAXVALUE",maxwidth,maxheight)

            m = 0
            centerwidth = -(max(objwidthlist)*rownum+(rownum-1)*maginw)/2+max(objwidthlist)/2
            centerheight =-(max(objheightlist)*column+(column-1)*maginh)/2+max(objheightlist)/2

            for o in range(column):
                for r in range(rownum):
                    
                    try:
                        if dircction=="Horizontal": 
                            objs[o*rownum+r].location = (centerwidth+maxwidth /
                                                rownum*r, centerheight+(maxheight)*o, 
                                                objs[o*rownum+r].location[2] if putcenter == "original" else findcenterz(objs[o*rownum+r]))
                        else:
                            objs[o*rownum+r].location = (centerwidth+maxwidth /
                                                rownum*r,
                                                objs[o*rownum+r].location[1] if putcenter == "original" else findcenterz(objs[o*rownum+r]),
                                                centerheight+(maxheight)*o)
                            
                    except:
                        pass
                            

        return {"FINISHED"}

    # bpy.ops.apply.transformall()
