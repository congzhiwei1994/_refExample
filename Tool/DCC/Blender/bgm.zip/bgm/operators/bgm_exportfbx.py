import bpy
import bmesh
import os


#-----Creater Folder----
def createrFolder(path):
    folder = os.path.exists(path)
    if folder==False:
        os.makedirs(path)
    return path

#-----Creater Folder----   

class bgmexportfbx(bpy.types.Operator):
    bl_idname = "my_operator.bgmexportfbxnew"
    bl_label = "Bgmexportfbx"
    bl_description = ""
    bl_options = {"REGISTER"}

    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):  
        meshtype=bpy.context.scene.meshtype
        parName=bpy.context.scene.fbxcommonname
        setCenter=bpy.context.scene.fbxsetcenter
        filepath = bpy.data.filepath
        directory = os.path.dirname(filepath)
        if meshtype=='fbx':
            bl2sppath=createrFolder(directory+"\\bgm2FBX\\")
        if meshtype=='obj':
            bl2sppath=createrFolder(directory+"\\bgm2OBJ\\")
        objlist=bpy.context.selected_objects
        if len(objlist)==0:
            self.report({'ERROR'},"Please Select Mesh Object!")
            return {"FINISHED"}
        for objs in objlist:
            #bpy.data.objects[objs.name].select=False
            bpy.data.objects[objs.name].select_set(state=False)

        for objss in objlist:
            
            bpy.context.view_layer.objects.active = objss
            #newpos=(objss.location[0],objss.location[1],objss.location[2])
            
            objold=bpy.context.view_layer.objects.active
            bpy.data.objects[objold.name].select_set(state=True)
            bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'}, TRANSFORM_OT_translate={"value":(0, 0, 0), "orient_type":'GLOBAL', "orient_matrix":((0, 0, 0), (0, 0, 0), (0, 0, 0)), "orient_matrix_type":'GLOBAL', "constraint_axis":(False, False, False), "mirror":False, "use_proportional_edit":False, "proportional_edit_falloff":'SMOOTH', "proportional_size":1, "use_proportional_connected":False, "use_proportional_projected":False, "snap":False, "snap_target":'CLOSEST', "snap_point":(0, 0, 0), "snap_align":False, "snap_normal":(0, 0, 0), "gpencil_strokes":False, "cursor_transform":False, "texture_space":False, "remove_on_cancel":False, "release_confirm":False, "use_accurate":False})
            obj=bpy.context.view_layer.objects.active
            if directory=="":
                    directory=os.path.abspath(os.path.dirname(os.path.split(os.path.realpath(__file__))[0]))
                    if meshtype=='fbx':
                        bl2sppath=createrFolder(directory+"\\bgm2FBX\\")
                    if meshtype=='obj':
                        bl2sppath=createrFolder(directory+"\\bgm2OBJ\\")
            #--------FIND CENTER---------
            if setCenter:
                findcenter(obj)
            #--------FIND CENTER---------
            if meshtype=='fbx':
                newpath=bl2sppath+parName+objss.name+".fbx"  
                bpy.ops.export_scene.fbx(filepath=newpath, use_selection=True) 
            if meshtype=='obj':
                newpath=bl2sppath+parName+objss.name+".obj"  
                bpy.ops.export_scene.obj(filepath=newpath, use_selection=True) 
            #--------Set POS---------
            # bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
            # bpy.data.objects[obj.name].location=newpos
            bpy.ops.object.delete(use_global=False)

            
            bpy.data.objects[objold.name].select_set(state=False)

        os.system("start explorer "+bl2sppath)        
        return {"FINISHED"}
        
def findcenter(obj):
    o = obj
    vcos = [ o.matrix_world @ v.co for v in o.data.vertices ]
    findCenter = lambda l: ( max(l) + min(l) ) / 2
    x,y,z  = [ [ v[i] for v in vcos ] for i in range(3) ]
    center = [ findCenter(axis) for axis in [x,y,z] ]             
    
    obj.location=(obj.location[0]-center[0],
    (obj.location[1]-center[1]),
    (obj.location[2]-center[2])+obj.dimensions.z/2)

    bpy.ops.object.transform_apply()
