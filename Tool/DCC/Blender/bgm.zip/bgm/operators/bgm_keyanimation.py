import bpy

class bgmkeyanimation(bpy.types.Operator):
    bl_idname = "my_operator.bgmkeyanimation"
    bl_label = "Bgmpaintersetting"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}

    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        #bpy.context.active_object.mode='POSE'
        keyset=bpy.context.scene.tool_settings.use_keyframe_insert_auto 
        bones=bpy.context.selected_pose_bones
        if bpy.context.selected_pose_bones!=None:
            bpy.ops.pose.select_all(action='TOGGLE')
        for b in bones:
            b.bone.select=True
            bpy.ops.anim.keyframe_insert_menu(type='WholeCharacterSelected')
            bpy.context.scene.tool_settings.use_keyframe_insert_auto = True
            bpy.ops.transform.rotate(value=0.00349066, orient_axis='Z', orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(False, False, True), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)

            bpy.context.scene.tool_settings.use_keyframe_insert_auto = True
            bpy.context.scene.tool_settings.use_keyframe_insert_auto = False

            bpy.ops.anim.keyframe_insert_menu(type='WholeCharacterSelected')
            bpy.context.scene.tool_settings.use_keyframe_insert_auto = True
            bpy.ops.transform.rotate(value=-0.00349066, orient_axis='Z', orient_type='GLOBAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), orient_matrix_type='GLOBAL', constraint_axis=(False, False, True), mirror=True, use_proportional_edit=False, proportional_edit_falloff='SMOOTH', proportional_size=1, use_proportional_connected=False, use_proportional_projected=False)

            bpy.context.scene.tool_settings.use_keyframe_insert_auto = True
            bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
            

            bpy.ops.pose.select_all(action='TOGGLE')
        for b in bones:
            b.bone.select=True
        bpy.context.scene.tool_settings.use_keyframe_insert_auto=keyset
        return {"FINISHED"}
        #bpy.data.objects['Armature.001'].pose.bones["mixamorig:RightArm"]
        #E:\pj_Unity\Shoot_FIX\Assets\Character


class bgmkeyclearanimationdata(bpy.types.Operator):
    bl_idname = "my_operator.bgmkeyclearanimationdata"
    bl_label = "Bgmpaintersetting"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}

    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        obj=bpy.context.active_object
        ani=obj.animation_data.action
        for f in ani.fcurves:
            bgm_datapath=f.data_path
            bgm_arrayindex=f.array_index
            info=[]
            if len(f.keyframe_points)>2:
                for point in f.keyframe_points:
                        info.append(point.co)
            
            if len(info)>2:
                devalue=[]
                for i in range(len(info)-2):
                    value_a=info[i]
                    value_b=info[i+1]
                    value_c=info[i+2]

                    a=round((value_a[1]-value_b[1]),5)
                    print(a,"a value....")
                    b=round((value_b[1]-value_c[1]),5)
                    
                    print(b,"b value....")
                    if a==b:
                        print(i+1,"equal.....")
                        devalue.append(info[i+1][0])
                        
                for d in devalue:
                        print(d,d,"delete....")
                        obj.keyframe_delete(data_path=bgm_datapath,index=bgm_arrayindex,frame=d)
                bpy.data.actions.update()

        return {"FINISHED"}

