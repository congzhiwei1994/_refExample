import bpy

class bgmsetnormal(bpy.types.Operator):
    bl_idname = "my_operator.bgmsetnormal"
    bl_label = "Bgmaddmodiifer"
    bl_description = ""
    bl_options = {"REGISTER",'UNDO'}
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        # setnormalvalue=bpy.context.scene.setnormal
        # bpy.ops.mesh.smoothen_normals(factor=setnormalvalue)
        return {"FINISHED"}




# import bpy,bmesh

# obj=bpy.context.active_object
# selectVex=[]

# bm=bmesh.from_edit_mesh(obj.data)

# vertices = bm.verts
# for i in vertices:
#     if i.select==True:
#         selectVex.append(i)

# for i in selectVex:
#     i.normal=(bpy.context.scene.setnormal,bpy.context.scene.setnormal,bpy.context.scene.setnormal)
#     i.co.x+=1
#     print(i.normal,"\n")
# bmesh.update_edit_mesh(obj.data)