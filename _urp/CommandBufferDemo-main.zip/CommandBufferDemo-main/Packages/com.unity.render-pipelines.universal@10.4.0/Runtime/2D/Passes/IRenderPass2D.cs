namespace UnityEngine.Experimental.Rendering.Universal
{
    internal interface IRenderPass2D
    {
        Renderer2DData rendererData { get; }
    }
}
